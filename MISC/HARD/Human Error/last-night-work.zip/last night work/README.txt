Recovered files from /home/user/

No binaries. No encryption.
Nothing hidden.

Or is there?

Apparently, there is a weird sequence in this guys work, i would personally classify him as weirdo and give him nothing for his work.
But sometimes he catches up his mistakes fast so i can praise him for that maybe be he is a one of a kind.
